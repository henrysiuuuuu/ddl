"""project_name URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from App import views

urlpatterns = [
    # path('student_list', views.student_list),
    path('train', views.train),
    path('predict', views.predict),
    path('index', views.indexpage),
    path('register', views.registerpage),
    path('registeraction', views.registeraction),
    path('login', views.loginpage),
    path('loginaction', views.loginaction),
    path('forgetpwd', views.forgetpwdpage),
    path('forgetpwdaction', views.forgetpwdaction),
    path('searchaction', views.searchaction),
    path('insertequip', views.insertequippage),
    path('insertequipaction', views.insertequipaction),
    path('updateequip/<str:equip_id>/', views.updateequippage, name="updateequip"),
    path('updateequipaction', views.updateequipaction),
    path('deleteequip/<str:equip_id>/', views.deleteequippage, name="deleteequip"),
    path('chart_view', views.chart_view, name="chart_view"),
    path('import_excel', views.import_excel, name='import_excel'),

]
