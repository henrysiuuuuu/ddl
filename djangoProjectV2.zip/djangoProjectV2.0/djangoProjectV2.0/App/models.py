from django.db import models


class User(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=50)
    unit = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    tel = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

class Equip(models.Model):
    id = models.AutoField(primary_key=True)
    equip_name = models.CharField(max_length=50)
    exist_num = models.IntegerField()
    rate = models.FloatField()
    period = models.DateTimeField('保养期限', auto_now_add=True)
    admin_per = models.CharField(max_length=50)




