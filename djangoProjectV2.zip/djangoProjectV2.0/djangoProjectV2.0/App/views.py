import numpy as np
import pandas as pd
from django.contrib import messages
from django.shortcuts import render, render_to_response, redirect

from App import models
from django.template.context_processors import csrf
from django.http import JsonResponse
from .models import User
from .models import Equip



def train(request):
    import numpy as np
    import os
    os.environ['CUDA_VISIBLE_DEVICES'] = '2'
    import pandas as pd
    import matplotlib.pyplot as plt
    window_size = 5
    num_epochs = 500
    lr = 0.01
    # 从文件中读取数据
    df = pd.read_csv('C:/Users/Henry/Desktop/1/djangoProjectV2.0/djangoProjectV2.0/data1.csv')
    # 选取除了第一列以外的所有列，并转换为浮点数类型
    df.iloc[:, 1:] = df.iloc[:, 1:].astype('float')
    # 将日期列转换为datetime格式
    df['date'] = pd.to_datetime(df['date'])
    max_value = float(df.iloc[:, 1].max())
    min_value = float(df.iloc[:, 1].min())
    # 将除日期列外的所有列进行归一化
    df.iloc[:, 1:] = (df.iloc[:, 1:] - df.iloc[:, 1:].min()) / (df.iloc[:, 1:].max() - df.iloc[:, 1:].min())
    # 将数据划分为训练集和测试集
    train_size = int(len(df) * 0.8)
    train_df = df.iloc[:train_size]
    test_df = df.iloc[train_size:]

    import torch
    from torch.utils.data import Dataset, DataLoader

    class TimeSeriesDataset(Dataset):
        def __init__(self, df, window_size):
            self.window_size = window_size
            self.data = df.to_numpy()

        def __len__(self):
            return len(self.data) - self.window_size

        def __getitem__(self, idx):
            x = self.data[idx:idx + self.window_size, 1:].astype(float)
            y = self.data[idx + self.window_size, 1:].astype(float)
            return torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)

    import torch.nn as nn
    import torch.nn.functional as F

    class LSTM(nn.Module):
        def __init__(self, input_size, hidden_size, num_layers, output_size):
            super(LSTM, self).__init__()
            self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
            self.fc1 = nn.Linear(hidden_size, 32)
            self.fc2 = nn.Linear(32, output_size)

        def forward(self, x):
            out, _ = self.lstm(x)
            out = self.fc1(out[:, -1, :])
            out = F.relu(out)
            out = self.fc2(out)
            return out

    def rmse(y_true, y_pred):
        return torch.sqrt(torch.mean((y_true - y_pred) ** 2))

    def mae(y_true, y_pred):
        return torch.mean(torch.abs(y_true - y_pred))

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 定义模型
    model = LSTM(input_size=6, hidden_size=64, num_layers=2, output_size=6).to(device)

    # 定义优化器和损失函数
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss()

    # 定义数据集和数据加载器
    train_dataset = TimeSeriesDataset(train_df, window_size=window_size)
    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)

    # 定义绘图函数

    def plot_graphs(y_true, y_pred, title):
        # 对y_true和y_pred进行反归一化
        y_true = [i * (max_value - min_value) + min_value for i in y_true]
        y_pred = [i * (max_value - min_value) + min_value for i in y_pred]

        plt.plot(y_true, label='True')
        plt.plot(y_pred, label='Predicted')
        plt.xlabel('Time')
        plt.ylabel('Consumption')
        plt.title(title)
        plt.legend()
        plt.show()

    # 训练模型

    train_loss_history = []
    for epoch in range(num_epochs):
        train_loss = 0.0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            outputs = model(x)
            loss = criterion(outputs, y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * x.size(0)
        train_loss /= len(train_dataset)
        train_loss_history.append(train_loss)
        print(f'Epoch [{epoch + 1}/{num_epochs}], Train Loss: {train_loss:.4f}')

    # 绘制训练过程中的loss曲线图
    plt.plot(train_loss_history)
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss')
    plt.show()

    # 在测试集上评估模型
    test_dataset = TimeSeriesDataset(test_df, window_size=window_size)
    test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

    test_rmse, test_mae = 0.0, 0.0
    test_true, test_pred = [], []
    with torch.no_grad():
        for x, y in test_loader:
            x, y = x.to(device), y.to(device)
            outputs = model(x)
            test_rmse += rmse(outputs, y).item() * x.size(0)
            test_mae += mae(outputs, y).item() * x.size(0)
            test_true += y[:, 0].tolist()
            test_pred += outputs[:, 0].tolist()
    test_rmse /= len(test_dataset)
    test_mae /= len(test_dataset)
    print(f'Test RMSE: {test_rmse:.4f}, Test MAE: {test_mae:.4f}')
    torch.save(model.state_dict(), 'model_weights.pt')
    # 绘制测试集上的预测结果
    plot_graphs(test_true, test_pred, 'Test Set')

    # 在训练集上评估模型
    train_true, train_pred = [], []
    with torch.no_grad():
        for i in range(window_size, len(train_df)):
            x = train_df.iloc[i - window_size:i, 1:].values
            x = torch.tensor(x, dtype=torch.float32).unsqueeze(0).to(device)
            y = train_df.iloc[i, 1]
            output = model(x)
            train_true.append(float(y))
            train_pred.append(output[:, 0].item())

    # 绘制训练集上的预测结果
    plot_graphs(train_true, train_pred, 'Train Set')

    return redirect('/index')

def predict(request):
    import numpy as np
    import os
    os.environ['CUDA_VISIBLE_DEVICES'] = '2'
    import pandas as pd
    import matplotlib.pyplot as plt
    window_size = 3
    # 从文件中读取数据
    df = pd.read_csv('data1.csv')
    # 选取除了第一列以外的所有列，并转换为浮点数类型
    df.iloc[:, 1:] = df.iloc[:, 1:].astype('float')
    # 将日期列转换为datetime格式
    df['date'] = pd.to_datetime(df['date'])
    max_value = float(df.iloc[:, 1].max())
    min_value = float(df.iloc[:, 1].min())
    # 将除日期列外的所有列进行归一化
    df1 = df.copy(deep=True)
    df.iloc[:, 1:] = (df.iloc[:, 1:] - df.iloc[:, 1:].min()) / (df.iloc[:, 1:].max() - df.iloc[:, 1:].min())
    # 将数据划分为训练集和测试集
    train_size = int(len(df) * 0.8)
    train_df = df.iloc[:train_size]
    test_df = df.iloc[train_size:]

    import torch
    from torch.utils.data import Dataset, DataLoader
    import torch.nn as nn
    import torch.nn.functional as F

    class LSTM(nn.Module):
        def __init__(self, input_size, hidden_size, num_layers, output_size):
            super(LSTM, self).__init__()
            self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
            self.fc1 = nn.Linear(hidden_size, 32)
            self.fc2 = nn.Linear(32, output_size)

        def forward(self, x):
            out, _ = self.lstm(x)
            out = self.fc1(out[:, -1, :])
            out = F.relu(out)
            out = self.fc2(out)
            return out

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    window_size = 5
    # 定义模型
    model = LSTM(input_size=6, hidden_size=64, num_layers=2, output_size=6).to(device)
    model.load_state_dict(torch.load('model_weights.pt'))
    model.to(device)

    def predict_future(future_time):
        # >= 1 且 int
        model.eval()
        with torch.no_grad():
            inputs = test_df.iloc[-window_size:, 1:].to_numpy()
            inputs = torch.tensor(inputs, dtype=torch.float32).unsqueeze(0).to(device)
            for i in range(future_time - 1):
                outputs = model(inputs)
                inputs = torch.cat((inputs, outputs.unsqueeze(0)), dim=1)
                inputs = inputs[:, -window_size:, :]
            outputs = model(inputs)
            outputs = outputs.cpu().numpy()[0]
            outputs = outputs * (df1.iloc[:, 1:].max().to_numpy() - df1.iloc[:, 1:].min().to_numpy()) + df1.iloc[:,
                                                                                                        1:].min().to_numpy()
            return outputs


    for i in range(21, 71, 1):
        future_time = i
        prediction = predict_future(future_time)
        print(f'预测第{future_time}个时刻的值为: {prediction}' )

    return redirect('/index')

def indexpage(request):
    # 查询全部的数据

    equip = Equip.objects.filter()

    return render(request, 'index.html', {'equip_list': equip})



def chart_view(request):
    equip_list = Equip.objects.filter()

    categories = []
    values = []

    for equip in equip_list:
        categories.append(equip.equip_name)
        values.append(equip.exist_num)


    data = {
        'categories': categories,
        'values': values
    }
    return JsonResponse(data)


def registerpage(request):
    return render(request, "register.html")

def loginpage(request):
    return render(request, "login.html")

def forgetpwdpage(request):
    return render(request, "forgetpwd.html")

def insertequippage(request):
    return render(request, "insertequip.html")

def updateequippage(request, equip_id):
    equip = Equip.objects.get(id=equip_id)  # QuerySet查询集类型
    print(equip)
    return render(request, "updateequip.html", {'equip': equip})

def deleteequippage(request, equip_id):
    Equip.objects.get(id=equip_id).delete()  # QuerySet查询集类型

    return redirect('/index')

def registeraction(request):
    msg = ""
    if request.method == 'POST':
        name = request.POST.get('name')
        tel = request.POST.get('tel')
        unit = request.POST.get('unit')
        username = request.POST.get('username')
        password = request.POST.get('password')
        repassword = request.POST.get('repassword')

        if password != repassword:
            msg += "两次密码输入不一致！"
            c = csrf(request)
            c.update({'msg': msg})
            return render_to_response('register.html', context=c)
        else:
            user = models.User(
                name = name,
                username=username,
                password=password,
                tel=tel,
                unit=unit
            )
            user.save()
            return render(request, 'login.html')

    return render(request, 'register.html')

def loginaction(request):
    msg = ""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = User.objects.filter(username=username, password=password).first()

        if not user:
            msg += "账号和密码不一致！"
            c = csrf(request)
            c.update({'msg': msg})
            return render_to_response('login.html', context=c)
        else:

            return redirect('/index')

    return render(request, 'login.html')

def forgetpwdaction(request):
    msg = ""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        name = request.POST.get('name')
        repassword = request.POST.get('repassword')

        if password != repassword:
            msg += "两次密码输入不一致！"
            c = csrf(request)
            c.update({'msg': msg})
            return render_to_response('forgetpwd.html', context=c)
        else:
            user = User.objects.filter(username=username, name=name).first()

            if not user:
                msg += "姓名和账号不一致！"
                c = csrf(request)
                c.update({'msg': msg})
                return render_to_response('forgetpwd.html', context=c)
            else:
                user.password = password

                user.save()
                return render(request, 'login.html')

    return render(request, 'forgetpwd.html')

def searchaction(request):
    if request.method == 'GET':
        equip_name = request.GET.get('equip_name')

        equip = Equip.objects.filter(equip_name__contains=equip_name)  # QuerySet查询集类型

        return render(request, 'index.html', {'equip_list': equip})


    return render(request, '/index')

def insertequipaction(request):

    if request.method == 'POST':
        equip_name = request.POST.get('equip_name')
        exist_num = request.POST.get('exist_num')
        rate = request.POST.get('rate')
        period = request.POST.get('period')
        admin_per = request.POST.get('admin_per')


        equip = models.Equip(
            equip_name=equip_name,
            exist_num=exist_num,
            rate=rate,
            period=period,
            admin_per=admin_per
        )
        equip.save()

    return redirect('/index')

def updateequipaction(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        equip_name = request.POST.get('equip_name')
        exist_num = request.POST.get('exist_num')
        rate = request.POST.get('rate')
        period = request.POST.get('period')
        admin_per = request.POST.get('admin_per')
        equip = Equip.objects.get(id=id)
        equip.equip_name = equip_name
        equip.exist_num = exist_num
        equip.rate = rate
        equip.period = period
        equip.admin_per = admin_per
        equip.save()

    return redirect('/index')

def import_excel(request):
    if request.method == 'POST':
        file = request.FILES['file']
        if file.name.endswith('.xlsx'):
            df = pd.read_excel(file)

            datas = np.array(df)

            for data in datas:
                equip = models.Equip(
                    equip_name=data[0],
                    exist_num=data[1],
                    rate=data[2],
                    period=data[3],
                    admin_per=data[4]
                )
                equip.save()

            # 处理Excel数据
            messages.success(request, '数据导入成功！')
            return redirect('/index')
        else:
            messages.error(request, '请选择Excel文件！')
    return redirect('/index')
